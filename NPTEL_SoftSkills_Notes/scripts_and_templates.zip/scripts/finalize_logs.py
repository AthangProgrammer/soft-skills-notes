import os, json, subprocess, datetime
ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
mp = os.path.join(ROOT, 'logs/coverage_manifest.json')
m = json.load(open(mp, encoding='utf8'))
pdfs = {}
for d, _, fs in os.walk(os.path.join(ROOT, 'pdf')):
    for f in sorted(fs):
        if f.endswith('.pdf'):
            fp = os.path.join(d, f)
            info = subprocess.run(['pdfinfo', fp], capture_output=True, text=True).stdout
            pages = int([l.split()[1] for l in info.splitlines() if l.startswith('Pages')][0])
            words = len(subprocess.run(['pdftotext', fp, '-'], capture_output=True, text=True).stdout.split())
            pdfs[os.path.relpath(fp, ROOT)] = {'pages': pages, 'words': words, 'bytes': os.path.getsize(fp)}
for n, rec in m['lectures'].items():
    w = rec['week']
    rec['pdf'] = f'pdf/weeks/week_{w:02d}.pdf'
q = json.load(open(os.path.join(ROOT, 'scripts/data/quiz.json'), encoding='utf8'))
issues = [
    'Lecture 3: the seventh C of communication is not spelled out in the book.',
    'Lectures 2 and 19: culture/definition attributed to “Alfred G. Smith” in places and to “Adam Smith” in the transcript.',
    'Transcript misspellings of names: Fiedler (“Fielder”, Lecture 41), Sherring/Shearring and Christian (Lecture 32), Goleman (“Richard Goleman”, Lecture 59), and similar.',
    'Speaking-rate discrepancy across lectures: 120–130 wpm (Lecture 51) versus 125–130 and 140–150 elsewhere; each lecture’s figure is recorded as cited.',
    'Lecture 30: the poet quoted is not named in the transcript.',
    'Lecture 31: etymology gloss “re = to send” versus “back”; recorded as in the source.',
    'Lecture 52: verbatim poem and speech lines from the lecture were summarised, not reproduced (copyright).',
    'Quiz: 13 of 185 items are labelled “Needs verification” because the book does not state the answer verbatim (see the note on each item).',
    'Quiz items of the unnumbered sample set (W0Q1–Q5) are outside the numbered weeks and are mapped to the closest lectures.',
    'Quiz page images were OCR’d; ambiguous items were checked against page images. No item is labelled Unreadable.']
m['pdfs'] = pdfs
m['issues'] = issues
m['updated'] = datetime.datetime.now().isoformat(timespec='seconds')
m['quiz']['status_counts'] = {s: sum(1 for x in q if x['status'] == s) for s in ('Verified', 'Needs verification', 'Unreadable')}
json.dump(m, open(mp, 'w', encoding='utf8'), ensure_ascii=False, indent=1)
log = ['NPTEL Soft Skills notes: processing log', f'Finished: {m["updated"]}', '',
       'Source: 109107121.pdf (1,026 pages, 60 lectures); Quiz.pdf (42 pages, 185 questions)',
       'Pipeline: extract_book.py -> per-lecture cleaned text; lec_NN.json written per lecture; build.py -> HTML; quiz_source.py + map_quiz.py (+ quiz_review.json) -> quiz analysis; make_pdfs.py (Playwright Chromium, A4); validate.py; finalize_logs.py', '',
       'Lectures with notes: 60/60 (12 weeks)', f'Quiz pages inspected: 42/42; questions analysed: {len(q)}',
       'Quiz status: ' + ', '.join(f'{k}={v}' for k, v in m['quiz']['status_counts'].items()), f'PDFs generated: {len(pdfs)}', '']
log += [f'  {k}: {v["pages"]} pages, {v["words"]} words' for k, v in sorted(pdfs.items())]
log += ['', 'Unresolved issues and caveats:'] + [f'  - {i}' for i in issues]
open(os.path.join(ROOT, 'logs/processing_log.txt'), 'w', encoding='utf8').write('\n'.join(log) + '\n')
print('\n'.join(log[:14]))
