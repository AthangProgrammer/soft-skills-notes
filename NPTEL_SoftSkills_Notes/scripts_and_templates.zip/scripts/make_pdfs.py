import os, sys, json, glob
from playwright.sync_api import sync_playwright

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
JOBS = [('complete_notes.html', 'pdf/NPTEL_SoftSkills_Complete_Notes.pdf', 'NPTEL Soft Skills – Complete Notes'),
        ('master_revision.html', 'pdf/NPTEL_SoftSkills_Master_Revision.pdf', 'NPTEL Soft Skills – Master Revision'),
        ('quiz_analysis.html', 'pdf/NPTEL_SoftSkills_Quiz_Analysis.pdf', 'NPTEL Soft Skills – Quiz Analysis'),
        ('practice_questions.html', 'pdf/NPTEL_SoftSkills_Practice_Questions.pdf', 'NPTEL Soft Skills – Practice Questions'),
        ('last_day_revision.html', 'pdf/NPTEL_SoftSkills_Last_Day_Revision.pdf', 'NPTEL Soft Skills – Last-Day Revision')]
JOBS += [(f'weeks/week_{w:02d}.html', f'pdf/weeks/week_{w:02d}.pdf', f'NPTEL Soft Skills – Week {w}') for w in range(1, 13)]

HEAD = ('<div style="font-size:8px;width:100%;padding:0 14mm;color:#555;display:flex;justify-content:space-between">'
        '<span>{t}</span><span>Soft Skills · Prof. Binod Mishra · IIT Roorkee</span></div>')
FOOT = ('<div style="font-size:8px;width:100%;padding:0 14mm;color:#555;text-align:center">'
        'Page <span class="pageNumber"></span> of <span class="totalPages"></span></div>')


def main():
    only = set(sys.argv[1:])
    done = []
    with sync_playwright() as p:
        b = p.chromium.launch()
        for src, out, title in JOBS:
            if only and out not in only and os.path.basename(out) not in only:
                continue
            pg = b.new_page()
            pg.goto('file://' + os.path.join(ROOT, src), wait_until='load')
            pg.emulate_media(media='print')
            os.makedirs(os.path.dirname(os.path.join(ROOT, out)), exist_ok=True)
            pg.pdf(path=os.path.join(ROOT, out), format='A4', print_background=True, display_header_footer=True,
                   header_template=HEAD.replace('{t}', title), footer_template=FOOT, outline=True, tagged=True,
                   margin={'top': '18mm', 'bottom': '16mm', 'left': '14mm', 'right': '14mm'})
            pg.close()
            done.append(out)
            print('wrote', out, os.path.getsize(os.path.join(ROOT, out)))
        b.close()
    return done


if __name__ == '__main__':
    main()
