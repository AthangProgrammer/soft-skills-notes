import json, os, html, datetime

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, 'scripts', 'data')
MANIFEST = os.path.join(ROOT, 'logs', 'coverage_manifest.json')
LOG = os.path.join(ROOT, 'logs', 'processing_log.txt')
WORK = '/home/claude/work'

WEEK_TITLES = {w: t for w, t in enumerate([
    '', 'Foundations of Soft Skills and Communication', 'Positivity, Telephone and Non-verbal Communication',
    'Space, Touch, Meta-communication and Listening', 'Negotiation, Culture and Organisational Communication',
    'Communication Breakdown and Business Writing', 'Business Writing and Business Letters',
    'Report Writing', 'Report Structure, Style and Group Communication', 'Leadership, Discussion, Meetings and Ethics',
    'Speaking, Presentations and Nervousness', 'Presentations, Speeches and Interviews',
    'Resume, Interviews, Emotional Intelligence and Grammar'])}


def load(name, default=None):
    p = os.path.join(DATA, name)
    if not os.path.exists(p):
        return default
    return json.load(open(p, encoding='utf8'))


def save(name, obj):
    json.dump(obj, open(os.path.join(DATA, name), 'w', encoding='utf8'), indent=1, ensure_ascii=False)


def lectures():
    return load('lectures.json')


def lec_data(n):
    return load(f'lec_{n:02d}.json')


def esc(s):
    return html.escape(str(s), quote=False)


def log(msg):
    with open(LOG, 'a', encoding='utf8') as f:
        f.write(f"{datetime.datetime.now().isoformat(timespec='seconds')} {msg}\n")


def manifest():
    if os.path.exists(MANIFEST):
        return json.load(open(MANIFEST, encoding='utf8'))
    return {'lectures': {}, 'quiz': {}, 'pdfs': {}, 'issues': []}


def save_manifest(m):
    m['updated'] = datetime.datetime.now().isoformat(timespec='seconds')
    json.dump(m, open(MANIFEST, 'w', encoding='utf8'), indent=1, ensure_ascii=False)
