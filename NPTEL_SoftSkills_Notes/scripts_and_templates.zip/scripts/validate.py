import os, re, sys, json
from html.parser import HTMLParser

ROOT = os.path.abspath(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..'))
VOID = {'meta', 'link', 'br', 'hr', 'img', 'input', 'col', 'area', 'base', 'source', 'wbr'}


class P(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.stack, self.errors, self.ids, self.hrefs, self.srcs, self.dup = [], [], set(), [], [], []
        self.text = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if 'id' in a:
            if a['id'] in self.ids:
                self.dup.append(a['id'])
            self.ids.add(a['id'])
        if tag == 'a' and a.get('href'):
            self.hrefs.append(a['href'])
        if tag in ('script', 'img') and a.get('src'):
            self.srcs.append(a['src'])
        if tag == 'link' and a.get('href'):
            self.srcs.append(a['href'])
        if tag not in VOID:
            self.stack.append(tag)

    def handle_endtag(self, tag):
        if tag in VOID:
            return
        if not self.stack or self.stack[-1] != tag:
            self.errors.append(f'unbalanced </{tag}> (open: {self.stack[-3:]})')
            if tag in self.stack:
                while self.stack and self.stack[-1] != tag:
                    self.stack.pop()
                self.stack.pop()
        else:
            self.stack.pop()

    def handle_data(self, d):
        self.text.append(d)


def html_files():
    out = []
    for d, _, fs in os.walk(ROOT):
        if '/scripts' in d or '/templates' in d:
            continue
        for f in fs:
            if f.endswith('.html'):
                out.append(os.path.join(d, f))
    return sorted(out)


def main():
    problems, pages = [], {}
    files = html_files()
    for f in files:
        p = P()
        p.feed(open(f, encoding='utf8').read())
        pages[f] = p
        rel = os.path.relpath(f, ROOT)
        if p.stack:
            problems.append(f'{rel}: unclosed tags {p.stack}')
        problems += [f'{rel}: {e}' for e in p.errors]
        problems += [f'{rel}: duplicate id {i}' for i in set(p.dup)]
    nlinks = 0
    for f, p in pages.items():
        rel = os.path.relpath(f, ROOT)
        base = os.path.dirname(f)
        for h in p.hrefs + p.srcs:
            if re.match(r'(https?:|mailto:|javascript:|#?$)', h):
                continue
            nlinks += 1
            path, _, frag = h.partition('#')
            tgt = os.path.normpath(os.path.join(base, path)) if path else f
            if not os.path.exists(tgt):
                problems.append(f'{rel}: broken link {h}')
            elif frag and tgt in pages and frag not in pages[tgt].ids:
                problems.append(f'{rel}: missing anchor {h}')
            elif frag and tgt.endswith('.html') and tgt not in pages:
                pass
    required = ['index.html', 'master_revision.html', 'important_comparisons.html', 'glossary.html', 'quiz_analysis.html',
                'practice_questions.html', 'last_day_revision.html', 'source_coverage.html', 'complete_notes.html',
                'assets/css/styles.css', 'assets/css/print.css', 'logs/processing_log.txt', 'logs/coverage_manifest.json']
    required += [f'weeks/week_{w:02d}.html' for w in range(1, 13)]
    for r in required:
        if not os.path.exists(os.path.join(ROOT, r)):
            problems.append(f'missing required file {r}')
    full = open(os.path.join(ROOT, 'complete_notes.html'), encoding='utf8').read()
    for n in range(1, 61):
        if f'id="L{n:02d}"' not in full and f'id="lec-{n:02d}"' not in full and f'id="lecture-{n}"' not in full and f'id="L{n}"' not in full:
            m = re.search(r'id="([^"]*%d)"' % n, full)
            if not m:
                problems.append(f'lecture {n} anchor missing in complete_notes.html')
    for w in range(1, 13):
        t = open(os.path.join(ROOT, f'weeks/week_{w:02d}.html'), encoding='utf8').read()
        if len(re.sub(r'<[^>]+>', ' ', t)) < 8000:
            problems.append(f'week {w} content too thin')
    q = json.load(open(os.path.join(ROOT, 'scripts/data/quiz.json'), encoding='utf8'))
    bad = [x['id'] for x in q if x['status'] not in ('Verified', 'Needs verification', 'Unreadable') or not x.get('support')]
    if bad:
        problems.append(f'quiz items with bad status/support: {bad}')
    print(f'html files checked: {len(files)}; local links checked: {nlinks}; quiz items: {len(q)}')
    print('PROBLEMS:' if problems else 'OK: no problems')
    for p in problems[:60]:
        print(' -', p)
    return 1 if problems else 0


if __name__ == '__main__':
    sys.exit(main())
