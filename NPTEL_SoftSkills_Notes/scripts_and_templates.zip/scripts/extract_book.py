import re, json, sys, os
SRC = sys.argv[1]; OUT = sys.argv[2]
os.makedirs(OUT + '/text', exist_ok=True)
pages = open(SRC, encoding='utf8', errors='ignore').read().split('\f')[:1026]
starts = {}
for i, p in enumerate(pages):
    m = re.search(r'Lecture\s*[-–—:]?\s*(\d+)', p[:900])
    if m and i > 3:
        starts.setdefault(int(m.group(1)), i + 1)
toc = open(SRC, encoding='utf8', errors='ignore').read().split('\f')[1:4]
titles, weeks, wk = {}, {}, 0
for blk in toc:
    for ln in blk.splitlines():
        w = re.match(r'\s*Week\s+(\d+)', ln)
        if w: wk = int(w.group(1)); continue
        m = re.match(r'\s*(\d{1,2})\s{2,}(.+?)\s{2,}(\d+)\s*$', ln)
        if m: titles[int(m.group(1))] = m.group(2).strip(); weeks[int(m.group(1))] = wk
lecs = []
for n in range(1, 61):
    s = starts[n]; e = starts[n + 1] - 1 if n < 60 else 1026
    txt = '\n'.join(pages[s - 1:e])
    txt = re.sub(r'\(Refer Slide Time:?[^)]*\)', '', txt)
    txt = re.sub(r'^\s*\d{1,4}\s*$', '', txt, flags=re.M)
    txt = re.sub(r'[ \t]+', ' ', txt)
    txt = re.sub(r'\n\s*\n+', '\n', txt)
    txt = re.sub(r'(?<![.?!:”"])\n(?=[a-z(“"])', ' ', txt)
    open(f'{OUT}/text/lec_{n:02d}.txt', 'w', encoding='utf8').write(txt)
    lecs.append(dict(id=n, title=titles[n], week=weeks[n], pdf_pages=[s, e], printed_pages=[s - 1, e - 1], chars=len(txt)))
json.dump(lecs, open(OUT + '/lectures.json', 'w'), indent=1)
print(len(lecs), sum(l['chars'] for l in lecs))
