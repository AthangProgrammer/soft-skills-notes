import os, re, sys, math
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

STOP = set('a an the of to in on and or is are was were be been being it its this that these those which who whom what with for as by at from into than then so such not no can could should would may might will shall do does did has have had if but also any all each other more most some there their they them he she his her you your we our us one two select apply following'.split())


def stem(w):
    for suf in ('ingly', 'ing', 'edly', 'ed', 'ly', 'es', 's'):
        if len(w) > len(suf) + 3 and w.endswith(suf):
            return w[:-len(suf)]
    return w


def toks(s):
    return [stem(w) for w in re.findall(r"[a-z0-9]+", s.lower().replace("'", '')) if w not in STOP and len(w) > 1]


def load_pages():
    txt = open(WORK + '/book.txt', encoding='utf8', errors='ignore').read().split('\f')[:1026]
    out = []
    for i, p in enumerate(txt):
        p = re.sub(r'\(Refer Slide Time:?[^)]*\)', ' ', p)
        p = re.sub(r'\s+', ' ', p)
        out.append(p)
    return out


def main():
    pages = load_pages(); lecs = lectures(); quiz = load('quiz.json')
    review = load('quiz_review.json', {})
    units = []
    for l in lecs:
        for pg in range(l['pdf_pages'][0], l['pdf_pages'][1] + 1):
            sents = re.split(r'(?<=[.?!])\s+', pages[pg - 1])
            for i in range(len(sents)):
                win = ' '.join(sents[i:i + 2])
                units.append((l['id'], pg, win, set(toks(win))))
    df = {}
    for u in units:
        for t in u[3]:
            df[t] = df.get(t, 0) + 1
    N = len(units)
    idf = lambda t: math.log((N + 1) / (df.get(t, 0) + 1)) + 0.1
    for q in quiz:
        ans = q['ans'] if isinstance(q['ans'], list) else [q['ans']]
        a_txt = ' '.join(ans) if q['type'] not in ('True/False', 'Match the columns') else ''
        qt = set(toks(q['q'] + (' ' + ' '.join(r[0] + ' ' + r[1] for r in q['match']) if q.get('match') else '')))
        at = set(toks(a_txt)) - qt if q['type'] in ('MCQ', 'MSQ', 'Fill-in-the-blank') else set()
        if q['type'] in ('MCQ', 'MSQ', 'Fill-in-the-blank') and not at:
            at = set(toks(a_txt))
        wq = sum(idf(t) for t in qt) or 1; wa = sum(idf(t) for t in at) or 1
        best = []
        rv = review.get(q['id'])
        cand = [u for u in units if u[0] in rv['lec']] if rv and rv.get('lec') else units
        for lid_, pg, win, ts in cand:
            qs = sum(idf(t) for t in qt & ts) / wq
            as_ = sum(idf(t) for t in at & ts) / wa if at else qs
            sc = (0.45 * qs + 0.55 * as_) * (1.15 if (q['week'] and lecs[lid_ - 1]['week'] == q['week']) else 1.0)
            best.append((sc, qs, as_, lid_, pg, win))
        best.sort(reverse=True)
        sc, qs, as_, lid_, pg, win = best[0]
        q['lec'] = [lid_]
        for b in best[1:40]:
            if not (rv and rv.get('lec')) and b[3] != lid_ and b[0] > 0.9 * sc and len(q['lec']) < 2:
                q['lec'].append(b[3])
        q['lec'].sort()
        q['support'] = f'Lecture {lid_}, printed p.{pg-1} (PDF p.{pg}): “…{win[:330].strip()}…”'
        q['score_match'] = round(sc, 2)
        strong = as_ >= 0.6 and qs >= 0.3 if q['type'] in ('MCQ', 'MSQ', 'Fill-in-the-blank') else qs >= 0.55
        q['status'] = 'Verified' if strong and q['type'] in ('MCQ', 'MSQ', 'Fill-in-the-blank') else 'Needs verification'
        r = review.get(q['id'])
        if r:
            q['status'] = r.get('status', q['status'])
            if r.get('lec'):
                q['lec'] = r['lec']
            if r.get('support'):
                q['support'] = r['support']
            if r.get('note'):
                q['note'] = r['note']
    save('quiz.json', quiz)
    from collections import Counter
    c = Counter(q['status'] for q in quiz)
    print(dict(c))
    m = manifest()
    m['quiz'] = {'pages_inspected': '42 of 42 (OCR for all pages; page images viewed for ambiguous, incorrect and matching items)',
                 'questions_extracted': len(quiz), 'status_counts': dict(c)}
    save_manifest(m)


if __name__ == '__main__':
    main()
