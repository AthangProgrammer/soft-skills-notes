import os, re, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import *

TPL = lambda n: open(os.path.join(ROOT, 'templates', n), encoding='utf8').read()
LECS = lectures()
BYWEEK = {}
for l in LECS:
    BYWEEK.setdefault(l['week'], []).append(l)
QUIZ = load('quiz.json', [])
QBYLEC = {}
for q in QUIZ:
    for n in q.get('lec', []):
        QBYLEC.setdefault(n, []).append(q)

DOCS = [('master_revision.html', 'Master revision'), ('important_comparisons.html', 'Important comparisons'),
        ('glossary.html', 'Glossary'), ('quiz_analysis.html', 'Quiz analysis'),
        ('practice_questions.html', 'Practice questions'), ('last_day_revision.html', 'Last-day revision'),
        ('source_coverage.html', 'Source coverage'), ('complete_notes.html', 'Complete notes (single file)')]


def lid(n):
    return f'L{n:02d}'


def sidebar(root):
    s = [f'<div class="brand">NPTEL Soft Skills</div><a href="{root}index.html">Home</a>', '<h2>Documents</h2>']
    s += [f'<a href="{root}{f}">{t}</a>' for f, t in DOCS]
    s.append('<h2>Weeks</h2>')
    for w in range(1, 13):
        s.append(f'<details><summary>Week {w}</summary>')
        s.append(f'<a href="{root}weeks/week_{w:02d}.html">Week overview</a>')
        for l in BYWEEK[w]:
            s.append(f'<a href="{root}weeks/week_{w:02d}.html#{lid(l["id"])}">{l["id"]}. {esc(l["title"])}</a>')
        s.append('</details>')
    return '\n'.join(s)


def page(title, body, root=''):
    return (TPL('base.html').replace('{{title}}', esc(title)).replace('{{root}}', root)
            .replace('{{sidebar}}', sidebar(root)).replace('{{body}}', body))


def write(rel, content):
    p = os.path.join(ROOT, rel)
    os.makedirs(os.path.dirname(p), exist_ok=True)
    open(p, 'w', encoding='utf8').write(content)


def table(t):
    if isinstance(t, list):
        t = {'rows': t}
    out = ['<div class="tw"><table>']
    if t.get('title'):
        out.append(f'<caption style="text-align:left;font-weight:700;padding:4px 0">{t["title"]}</caption>')
    if t.get('head'):
        out.append('<thead><tr>' + ''.join(f'<th>{c}</th>' for c in t['head']) + '</tr></thead>')
    out.append('<tbody>' + ''.join('<tr>' + ''.join(f'<td>{c}</td>' for c in r) + '</tr>' for r in t['rows']) + '</tbody></table></div>')
    return ''.join(out)


def box(kind, label, inner):
    return f'<div class="box {kind}"><span class="lbl">{label}</span>{inner}</div>'


def ul(items):
    return '<ul>' + ''.join(f'<li>{i}</li>' for i in items) + '</ul>'


def pq_html(q, i):
    o = ''
    if q.get('o'):
        o = '<ol class="opts">' + ''.join(f'<li>{x}</li>' for x in q['o']) + '</ol>'
    a = f'<div class="ans"><b>Answer:</b> {q["a"]}' + (f'<br><b>Why:</b> {q["e"]}' if q.get('e') else '') + '</div>'
    return f'<div class="pq"><b>Q{i}</b> <span class="tag">{q["t"]}</span> {q["q"]}{o}{a}</div>'


PFX = ['../']


def quiz_refs(n):
    qs = QBYLEC.get(n, [])
    if not qs:
        return ''
    rows = []
    for q in qs:
        rows.append([f'W{q["week"]} Q{q["n"]}', f'p.{q["page"]}', q['concept'] if q.get('concept') else '', esc(q['type'])])
    return box('qz', 'Quiz-related concepts (quiz PDF page references)',
               table({'head': ['Question', 'Quiz PDF page', 'Concept tested', 'Type'], 'rows': rows}) +
               '<p class="meta">Full question text and answers: <a href="'+PFX[0]+'quiz_analysis.html">Quiz analysis</a>.</p>')


def render_lecture(l, h=2):
    n = l['id']; d = lec_data(n)
    o = [f'<section class="lecture" id="{lid(n)}">',
         f'<h2>Lecture {n}: {esc(l["title"])}</h2>',
         f'<p class="meta">Week {l["week"]} · Course book PDF pages {l["pdf_pages"][0]}–{l["pdf_pages"][1]} (printed pages {l["printed_pages"][0]}–{l["printed_pages"][1]})</p>']
    if not d:
        o.append(box('imp', 'Pending', '<p>Notes for this lecture have not been generated yet.</p>'))
        o.append('</section>'); return '\n'.join(o)
    o.append('<h3>Learning objectives</h3>' + ul(d['objectives']))
    if d.get('definitions'):
        o.append('<h3>Important definitions</h3>')
        o += [box('def', esc(t) if '<' not in t else t, f'<p>{x}</p>') for t, x in d['definitions']]
    o.append('<h3>Core concepts</h3>')
    for hd, body in d['concepts']:
        o.append(f'<h4>{hd}</h4>{body}')
    for t in d.get('classifications', []):
        o.append('<h3>Types, classifications and characteristics</h3>' if t is d['classifications'][0] else '')
        o.append(table(t))
    if d.get('theories'):
        o.append('<h3>Theories, principles, models and contributors</h3>')
        for nm, who, body in d['theories']:
            o.append(box('imp', f'{nm}' + (f' — {who}' if who else ''), body))
    if d.get('examples'):
        o.append('<h3>Examples and applications</h3>' + ''.join(box('ex', 'Example', f'<p>{x}</p>') for x in d['examples']))
    if d.get('comparisons'):
        o.append('<h3>Comparison tables</h3>' + ''.join(table(t) for t in d['comparisons']))
    if d.get('facts'):
        o.append('<h3>Important facts for MCQ revision</h3>' + box('tip', 'Exam tip', ul(d['facts'])))
    o.append(quiz_refs(n))
    o.append('<h3>Summary</h3><p>' + d['summary'] + '</p>')
    o.append('<h3>Practice questions</h3>' + ''.join(pq_html(q, i + 1) for i, q in enumerate(d['practice'])))
    o.append('<h3>Revision checklist</h3><ul class="chk">' + ''.join(f'<li>{c}</li>' for c in d['checklist']) + '</ul>')
    o.append('</section>')
    return '\n'.join(x for x in o if x)


def week_nav(w):
    p = f'<a href="week_{w-1:02d}.html">&larr; Week {w-1}</a>' if w > 1 else '<span></span>'
    nx = f'<a href="week_{w+1:02d}.html">Week {w+1} &rarr;</a>' if w < 12 else '<span></span>'
    return f'<div class="nav">{p}<a href="../index.html">Home</a>{nx}</div>'


def week_body(w, root_nav=True):
    ls = BYWEEK[w]
    toc = ''.join(f'<li><a href="#{lid(l["id"])}">Lecture {l["id"]}: {esc(l["title"])}</a></li>' for l in ls)
    return (TPL('week.html').replace('{{n}}', str(w)).replace('{{week_title}}', esc(WEEK_TITLES[w]))
            .replace('{{range}}', f'{ls[0]["id"]}–{ls[-1]["id"]}').replace('{{toc}}', toc)
            .replace('{{lectures}}', ''.join(render_lecture(l) for l in ls)))


def rev_body(heading, intro, content):
    return (TPL('revision.html').replace('{{heading}}', esc(heading)).replace('{{intro}}', intro)
            .replace('{{content}}', content))


def build_weeks():
    for w in range(1, 13):
        write(f'weeks/week_{w:02d}.html', page(f'Week {w} Notes — NPTEL Soft Skills', week_body(w) + week_nav(w), '../'))


def build_complete():
    PFX[0] = ''
    body = ['<h1>NPTEL Soft Skills — Complete Notes</h1><p class="meta">All 12 weeks, 60 lectures</p>',
            '<nav class="toc"><strong>Contents</strong><ol>' + ''.join(
                f'<li><a href="#W{w}">Week {w}: {WEEK_TITLES[w]}</a></li>' for w in range(1, 13)) + '</ol></nav>']
    for w in range(1, 13):
        body.append(f'<h1 id="W{w}" style="break-before:page">Week {w}: {WEEK_TITLES[w]}</h1>')
        body.append('<nav class="toc"><ol>' + ''.join(
            f'<li><a href="#{lid(l["id"])}">Lecture {l["id"]}: {esc(l["title"])}</a></li>' for l in BYWEEK[w]) + '</ol></nav>')
        body += [render_lecture(l) for l in BYWEEK[w]]
    write('complete_notes.html', page('NPTEL Soft Skills — Complete Notes', '\n'.join(body)))
    PFX[0] = '../'


def all_data():
    return [(l, lec_data(l['id'])) for l in LECS]


def build_master():
    b = []
    for w in range(1, 13):
        b.append(f'<h2 id="W{w}">Week {w}: {WEEK_TITLES[w]}</h2>')
        for l in BYWEEK[w]:
            d = lec_data(l['id'])
            b.append(f'<h3>Lecture {l["id"]}: {esc(l["title"])} <a class="meta noprint" href="weeks/week_{w:02d}.html#{lid(l["id"])}">(full notes)</a></h3>')
            if not d:
                b.append('<p><em>Pending.</em></p>'); continue
            b.append(f'<p>{d["summary"]}</p>')
            if d.get('facts'):
                b.append(box('tip', 'Key facts', ul(d['facts'][:6])))
            b.append('<ul class="chk">' + ''.join(f'<li>{c}</li>' for c in d['checklist']) + '</ul>')
    write('master_revision.html', page('Master Revision — NPTEL Soft Skills', rev_body('Master Revision Guide', 'Compact full-syllabus revision: summaries, key facts and checklists for all 60 lectures.', '\n'.join(b))))


def build_comparisons():
    b = ['<h1>Important Comparisons</h1><p class="meta">Concepts that are easy to confuse, collected from every lecture.</p>']
    n = 0
    for w in range(1, 13):
        parts = []
        for l in BYWEEK[w]:
            d = lec_data(l['id'])
            for t in (d or {}).get('comparisons', []):
                parts.append(f'<p class="meta">Lecture {l["id"]}: {esc(l["title"])}</p>' + table(t)); n += 1
        if parts:
            b.append(f'<h2>Week {w}</h2>' + ''.join(parts))
    write('important_comparisons.html', page('Important Comparisons — NPTEL Soft Skills', '\n'.join(b)))
    return n


def build_glossary():
    terms = {}
    for l, d in all_data():
        if not d:
            continue
        for t, x in d.get('definitions', []) + d.get('glossary', []):
            k = re.sub('<[^>]+>', '', t).strip()
            terms.setdefault(k.lower(), [k, x, []])[2].append(l['id'])
    b = ['<h1>Glossary</h1><p class="meta">Alphabetical list of key terms with the lecture(s) where they appear.</p>']
    cur = ''
    letters = sorted({v[0][0].upper() for v in terms.values()})
    b.append('<nav class="toc"><strong>Jump to:</strong> ' + ' '.join(f'<a href="#g{c}">{c}</a>' for c in letters) + '</nav>')
    rows = []
    for k in sorted(terms, key=lambda s: re.sub(r'[^a-z0-9]', '', s)):
        t, x, ls = terms[k]
        c = t[0].upper()
        if c != cur:
            if rows:
                b.append('<dl>' + ''.join(rows) + '</dl>'); rows = []
            b.append(f'<h2 id="g{c}">{c}</h2>'); cur = c
        refs = ', '.join(f'<a href="weeks/week_{LECS[i-1]["week"]:02d}.html#{lid(i)}">L{i}</a>' for i in sorted(set(ls)))
        rows.append(f'<dt><strong>{t}</strong> <span class="meta">({refs})</span></dt><dd>{x}</dd>')
    if rows:
        b.append('<dl>' + ''.join(rows) + '</dl>')
    write('glossary.html', page('Glossary — NPTEL Soft Skills', '\n'.join(b)))
    return len(terms)


def build_practice():
    b = ['<h1>Practice Questions</h1><p class="meta">Original practice questions with answers and explanations, by week and question type.</p>',
         '<button class="btn noprint" id="toggle-ans">Hide answers</button>']
    cnt = 0
    for w in range(1, 13):
        b.append(f'<h2 id="W{w}">Week {w}: {WEEK_TITLES[w]}</h2>')
        groups = {}
        for l in BYWEEK[w]:
            d = lec_data(l['id'])
            for q in (d or {}).get('practice', []):
                groups.setdefault(q['t'], []).append((l['id'], q)); cnt += 1
        for t in ['MCQ', 'MSQ', 'T/F', 'Fill', 'Match', 'Short']:
            if t in groups:
                b.append(f'<h3>{t}</h3>')
                b += [pq_html(dict(q, q=f'<span class="meta">[L{i}]</span> {q["q"]}'), k + 1) for k, (i, q) in enumerate(groups[t])]
    write('practice_questions.html', page('Practice Questions — NPTEL Soft Skills', '\n'.join(b)))
    return cnt


def build_lastday():
    b = []
    for w in range(1, 13):
        b.append(f'<h2 id="W{w}">Week {w}</h2>')
        for l in BYWEEK[w]:
            d = lec_data(l['id'])
            if d and d.get('key'):
                b.append(f'<h3>L{l["id"]}. {esc(l["title"])}</h3>' + ul(d['key']))
    write('last_day_revision.html', page('Last-Day Revision — NPTEL Soft Skills', rev_body('Last-Day Revision Sheet', 'Essential definitions, models, distinctions and facts, one block per lecture.', '\n'.join(b))))


def qcard(q):
    st = q.get('status', 'Needs verification')
    cls = 'Needs' if st.startswith('Needs') else st
    o = ''
    if q.get('match'):
        o += table({'head': ['Column A', 'Column B'], 'rows': q['match']})
    if q.get('opts'):
        o += '<ol class="opts">' + ''.join(f'<li>{esc(x)}</li>' for x in q['opts']) + '</ol>'
    lecs = ', '.join(f'L{n} {esc(LECS[n-1]["title"])}' for n in q.get('lec', [])) or '—'
    sel = q.get('sel') or q['ans']
    sc = q.get('score', 1)
    ans = ' | '.join(q['ans']) if isinstance(q['ans'], list) else q['ans']
    sel = ' | '.join(sel) if isinstance(sel, list) else sel
    sup = f'<br><b>Book support:</b> {q["support"]}' if q.get('support') else ''
    note = f'<br><b>Note:</b> {esc(q["note"])}' if q.get('note') else ''
    return (f'<div class="pq" id="{q["id"]}"><span class="tag t-{cls}">{st}</span> <b>{q["id"]}</b> · PDF p.{q["page"]} · {esc(q["type"])}'
            f'<p>{esc(q["q"])}</p>{o}<div class="ans"><b>Accepted answer:</b> {esc(ans)}<br><b>Selected response:</b> {esc(sel)} '
            f'(score {sc}/1)<br><b>Week/Lecture:</b> {"Sample set (unnumbered)" if not q["week"] else "Week " + str(q["week"])} · {lecs}<br><b>Concept:</b> {esc(q.get("concept", ""))}{sup}{note}</div></div>')


def build_quiz():
    b = ['<h1>Quiz Analysis</h1>']
    if not QUIZ:
        b.append('<p>No quiz data yet.</p>')
    else:
        from collections import Counter
        c = Counter(q.get('status', 'Needs verification') for q in QUIZ)
        b.append(f'<p class="meta">{len(QUIZ)} questions from the Quiz PDF (42 pages, 13 assignments: Week 0–12). Status: '
                 f'{c.get("Verified",0)} Verified · {c.get("Needs verification",0)} Needs verification · {c.get("Unreadable",0)} Unreadable.</p>')
        b.append(box('def', 'Status labels', '<p><b>Verified</b>: the accepted answer is shown on the portal screenshot and a supporting passage was found in the course book (or confirmed on review). '
                     '<b>Needs verification</b>: answer is readable on the screenshot but the book passage could not be confirmed automatically. '
                     '<b>Unreadable</b>: not reliably readable. “Accepted answer” is the portal’s answer; “Selected response” is the option ticked in the screenshot.</p>'))
        by = {}
        for q in QUIZ:
            by.setdefault(q['week'], []).append(q)
        b.append('<nav class="toc"><strong>Assignments:</strong> ' + ' '.join(f'<a href="#A{w}">Week {w}</a>' for w in sorted(by)) + '</nav>')
        for w in sorted(by):
            pg = sorted({q['page'] for q in by[w]})
            b.append(f'<h2 id="A{w}">Week {w} Assignment (PDF pp. {pg[0]}–{pg[-1]}, {len(by[w])} questions)</h2>')
            b += [qcard(q) for q in by[w]]
    write('quiz_analysis.html', page('Quiz Analysis — NPTEL Soft Skills', '\n'.join(b)))


def build_coverage():
    m = manifest()
    rows = []
    for l in LECS:
        s = m['lectures'].get(str(l['id']), {})
        rows.append([l['id'], f'W{l["week"]}', esc(l['title']), f'{l["pdf_pages"][0]}–{l["pdf_pages"][1]}', s.get('extraction', '—'),
                     s.get('notes', '—'), s.get('validation', '—'), s.get('quiz_questions', 0), s.get('pdf', '—')])
    b = ['<h1>Source Coverage Report</h1>', f'<p class="meta">Generated from logs/coverage_manifest.json · updated {m.get("updated","")}</p>',
         table({'head': ['#', 'Week', 'Lecture', 'Book PDF pages', 'Extraction', 'Notes', 'Validation', 'Quiz Qs', 'PDF'], 'rows': rows})]
    q = m.get('quiz', {})
    b.append('<h2>Quiz PDF</h2>' + ul([f'{k}: {esc(v)}' for k, v in q.items()]))
    b.append('<h2>PDF outputs</h2>' + ul([f'{k}: {esc(v)}' for k, v in m.get('pdfs', {}).items()]))
    b.append('<h2>Unresolved issues</h2>' + (ul([esc(i) for i in m.get('issues', [])]) or '<p>None recorded.</p>'))
    write('source_coverage.html', page('Source Coverage — NPTEL Soft Skills', '\n'.join(b)))


def build_index():
    cards = ''.join(f'<div class="card"><a href="weeks/week_{w:02d}.html">Week {w}</a><br><span class="meta">{WEEK_TITLES[w]}</span><br>'
                    f'<span class="meta">Lectures {BYWEEK[w][0]["id"]}–{BYWEEK[w][-1]["id"]}</span></div>' for w in range(1, 13))
    docs = ''.join(f'<div class="card"><a href="{f}">{t}</a></div>' for f, t in DOCS)
    b = ['<h1>NPTEL Soft Skills — Exam Notes</h1>',
         '<p>Exam-oriented notes for the NPTEL <em>Soft Skills</em> course (Prof. Binod Mishra): 12 weeks, 60 lectures, with quiz analysis, '
         'practice questions and revision sheets. Fully offline; open any file directly in a browser. PDFs are in the <code>pdf/</code> folder.</p>',
         '<h2>Weekly notes</h2><div class="cards">' + cards + '</div>', '<h2>Revision and reference</h2><div class="cards">' + docs + '</div>',
         '<h2>PDF downloads</h2><ul><li><a href="pdf/NPTEL_SoftSkills_Complete_Notes.pdf">Complete notes</a></li>'
         '<li><a href="pdf/NPTEL_SoftSkills_Master_Revision.pdf">Master revision</a></li>'
         '<li><a href="pdf/NPTEL_SoftSkills_Quiz_Analysis.pdf">Quiz analysis</a></li>'
         '<li><a href="pdf/NPTEL_SoftSkills_Practice_Questions.pdf">Practice questions</a></li>'
         '<li><a href="pdf/NPTEL_SoftSkills_Last_Day_Revision.pdf">Last-day revision</a></li>'
         '<li>Weekly PDFs: ' + ', '.join(f'<a href="pdf/weeks/week_{w:02d}.pdf">W{w}</a>' for w in range(1, 13)) + '</li></ul>']
    write('index.html', page('NPTEL Soft Skills — Notes', '\n'.join(b)))


def update_manifest():
    m = manifest()
    for l in LECS:
        n = l['id']
        s = m['lectures'].setdefault(str(n), {})
        s.update(title=l['title'], week=l['week'], pdf_pages=l['pdf_pages'],
                 extraction='done' if os.path.exists(f'{WORK}/text/lec_{n:02d}.txt') else 'pending',
                 notes='done' if lec_data(n) else 'pending', quiz_questions=len(QBYLEC.get(n, [])))
    save_manifest(m)


if __name__ == '__main__':
    build_weeks(); build_complete(); build_master(); nc = build_comparisons(); ng = build_glossary()
    npq = build_practice(); build_lastday(); build_quiz(); update_manifest(); build_coverage(); build_index()
    done = sum(1 for l in LECS if lec_data(l['id']))
    print(f'built: lectures with notes {done}/60, comparisons {nc}, glossary {ng}, practice {npq}')
